# Notion ile Ücretsiz Web Sitesi Oluşturmak

## Notion Nedir?

Notion sağladığı zengin bileşenler ve hayli özelleştirilebilir yapısı ile çok fazla amaç için kullanılabilen bir platform. Not alma, bilgi platformu olarak kullanma, blog yazılarınızı kaydetme, yapılacaklar listesi oluşturma, kanban paneller, database oluşturma, proje planlama, ortak çalışma alanları yaratma, hazırladığınız sayfaların HTML veya Markdown olarak çıktısını alma gibi bir çok amaç için kullanılabilen, hem mobil, hem masaüstü (yalnızca macOS ve Windows) hem de bir web app olarak hizmet verebilen bir uygulama. 2016'da San Fransisco merkezli kurulan ve 2020 yılında 2 milyar dolar değerleme alan bir şirket aynı zamanda. 

Yanlış hatırlamıyorsam bir Evernote alternatifi olarak beta sürümünü görmüştüm ilk defa. Hiç bir zaman Evernote'a ısınamamış biri olarak ilgimi çekmişti ancak resmi bir Linux versiyonunun olmayışı biraz uzak kalmama sebep olmuştu. Bugünse hala resmi bir API'a sahip olmayışları ve yol planlarında resmi API için öncelik barındırmamaları hala canımı sıksa da, bu benim gibi kullanıcılar için bir problem. Çok spesifik ihtiyaçlarınız yoksa bir çok uygulamanızı bırakıp Notion'a geçmemeniz için hiç bir sepep yok.

Bu blog yazısında Stephen Ou'nun bir yan projesi olan FruitionSite sitesinde yayınladığı yöntemi uygulayarak Notion ile nasıl bir web sayfası yapılır onu göstermeye çalışacağım.

### Notion yapılan web sayfası örnekleri nelerdir?

Aşağıdaki görsellerde Notion ile yapılan web sayfası örneklerinden bir kaç tanesini bulabilirsiniz.

Ayrıca bu yazıda gösterilecek olan yöntemle yapılmış sitelerin listesine de buradan ulaşabilirsiniz: [Fruition Showcase](https://fruitionsite.com/showcase).

---

## Notion İle Ücretsiz Web Sayfası Oluşturalım

Ben daha öncede GoDaddy'den aldığım no-kod.com alan adını bu örnek gösterim için kullanacağım. Herhangi bir alan adı sağlayıcısından almış olduğunuz alan adıyla da pek tabi bu işlemi gerçekleştirebilirsiniz. Tutarlı olmak ve örnek verirken kolaylık olması maksadıyla kendi kullanacağım alan adını tüm örneklerde kullanacağım.

### Notion ile Web Sayfası Yapmak için Gerekenler

Notion ile ücretsiz web sayfası oluşturmak için gereken iki önemli husus var. Bunlar:

- [ ]  Bir Notion hesabımızın olması.
- [ ]  Bir alan adına sahip olmamız (Örneğin: no-kod.com. Herhangi bir alan adı sağlayıcısından ücretli olarak temin edebilirsiniz: GoDaddy gibi)

Şu ana kadar zaten Notion hesabına sahip olduğunuzu ve de web sayfası olarak kullanmak istediğiniz alan adını almış olduğunuzu varsayıyorum. Bundan sonraki kısımda bir CloudFlare hesabı açıp, alan adınıza gelen trafiği Notion sayfanıza yönlendireceğiz. 

### Adım Adım Notion ile Web Sayfamızı oluşturuyoruz

1. [Buradaki adresten](https://dash.cloudflare.com/sign-up) ücretsiz bir CloudFlare üyeliği açıp. Eposta onayı için gelen maili onaylayın. 
2. "Add A Site"  butonuna tıklayarak kullanmak istediğiniz alan adınızı başında herhangi bir protokol ve alt alan adı olmadan girin. Örneğin: no-kod.com. 

    Eğer www.no-kod.com ya da blog.no-kod.com gibi bir alt alan adını kullanacak da olsam gene de kök alan adını yani apex domain'im olan no-kod.com 'u girecektim. 

3. Daha sonra "Free" seçeği ile ücretsiz planı seçiyoruz. 
4. Bize alan adı sağlayıcımızla ilgili bilgileri gösterdikten sonra "Continue" ile devam ediyoruz.
5.  CloudFlare'in ad sunucularının olduğu ekrana geldik. Buradaki 2 adet ad sunucusunu (name servers) kendi alan adı sağlayıcımızın DNS ayarlarına gireceğiz. Böylece CloudFlare alan adımızla ilgili tek yetkili konumuna gelecek.  

    ![https://cbsofyalioglucom.imfast.io/notion/1-cloudflare-nameservers.png](https://cbsofyalioglucom.imfast.io/notion/1-cloudflare-nameservers.png)

6. Alan adı sağlayıcımızda oturum açıp, kullanacağımız alan adının DNS ayarları sayfasına gidiyoruz. Benim örneğimi referans alırsak, GoDaddy'de oturum açıp, alan adlarım arasından no-kod.com' u bulup "Yönet" seçeneğine tıklıyorum.

    ![https://cbsofyalioglucom.imfast.io/notion/godaddy-dns-yonet.png](https://cbsofyalioglucom.imfast.io/notion/godaddy-dns-yonet.png)

7. Açılan sayfada alt kısımlarda Ad Sunucuları başlığında "Değiştir" butonuna tıklayarak, 5.Adımda karşımıza çıkan CloudFlare Ad Sunucularını (NS) buraya girip kaydediyoruz.

    Kaydetmenin ardından artık CloudFlare alan adımız üzerinde tam yetkiye sahip oluyor.

    ![https://cbsofyalioglucom.imfast.io/notion/1-cloudflare-nameservers.png](https://cbsofyalioglucom.imfast.io/notion/1-cloudflare-nameservers.png)

    Beş numaralı adımdaki CloudFlare Ad Sunucularını kopyalayıp, alan adımızın ad sunucuları olarak kaydediyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/godaddy-yeni-ad-sunucular%C4%B1.png](https://cbsofyalioglucom.imfast.io/notion/godaddy-yeni-ad-sunucular%C4%B1.png)

    Alan adımız yeni Ad Sunucularını kaydettikten sonra

8. Şimdi tekrardan CloudFlare'deki hesabımıza geri dönüyoruz.  "Done, check nameservers"  butonuna tıklıyoruz. 
9. Sonraki ekranda SSL/TLS modu olarak Flexible'ı seçiyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/2-cloudflare-ssl-flexible-sec.png](https://cbsofyalioglucom.imfast.io/notion/2-cloudflare-ssl-flexible-sec.png)

10. Always Use HTTPS seçeneğine tıklayarak aktif ediyor, Auto Minify seçeneklerinin hepsini seçiyor ve Brotli sıkıştırmasını da aktif ederek "Done" butonuna tıklıyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/3-cloudflare-minify-ve-brotli-sikistirma-sec.png](https://cbsofyalioglucom.imfast.io/notion/3-cloudflare-minify-ve-brotli-sikistirma-sec.png)

11. Ardından CloudFlare'in onay vermesini bekliyoruz. Eğer aşağıdaki ekran sizde çıkmadıysa, sayfayı yenileyebilirsiniz.

    ![https://cbsofyalioglucom.imfast.io/notion/4-cloudflare-basarili.png](https://cbsofyalioglucom.imfast.io/notion/4-cloudflare-basarili.png)

12. İşlemlerin başarılı olduğuna dair ekranı gördüyseniz, yukarıdaki mavi kutulardan "Workers" seçeneğini seçebilirsiniz. Yeni açılan sayfada, sağ taraftaki "Manage Workers" seçeneğine tıklayarak alan adına gelen trafiği, notion sayfamıza yönlendirecek worker'ımızı ayarlayacağız.

    ![https://cbsofyalioglucom.imfast.io/notion/5-cloudflare-workers-sayfasi.png](https://cbsofyalioglucom.imfast.io/notion/5-cloudflare-workers-sayfasi.png)

13. Sonraki ekranda çıkan herhangi bir alt alan adını seçebilirsiniz. Neyi seçitiğinizin çok da bir önemi yok. Global olarak benzersiz olması yeterli. Daha sonra "Set up" ve ardından "Confirm" seçenekleri ile işçimizi yaratıyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/6-no-kod-iscisi.png](https://cbsofyalioglucom.imfast.io/notion/6-no-kod-iscisi.png)

14. Sonraki ekranda tekrardan Free seçeneğini seçerek ücretsiz plan dahilinde kalıyoruz. Burada seçtiğimiz ücretsiz hesap için günlük bir limit uygulanıyor. Eğer siteniz fazla trafik çekecek ise daha sonra bir üst paketi seçebilirsiniz.
15. Eğer başka bir ekrandaysanız tekrardan mavi kutucuklar arasından Workers'a tıklayarak ilgili sayfaya geçiniz. Buradaki "Create a Worker" butonuna tıklayarak işçimizin görevlerini tanımlayacağız.
16. Bundan önce yapmamız gereken bir şey daha var. O da Notion'da oluşturduğumuz sayfaya giderek, bu sayfayı herkesin erişimine açık hale getirmek. Kullanacağımız sayfayı seçtikten sonra sağ üst köşedeki "Share" linkine tıklayarak ardından da "Share to the web" seçeneğini aktif hale getirip, "Copy Link" butonuna tıklıyor ve Notion sayfamızın global adresini kopyalıyoruz. Artık sayfamız herkesin erişimine açık hale gelmiş bulunmakta. 

    ![https://cbsofyalioglucom.imfast.io/notion/notion-paylasima-ac.png](https://cbsofyalioglucom.imfast.io/notion/notion-paylasima-ac.png)

17. Aşağıdaki kutucukların ilkine kullanacağınız alan adını girin. Örneğin: no-kod.com. İkincisine ise bir önceki adımda kopyaladığımız, Notion sayfamızın web adresini giriyoruz.  Ardından "COPY THE CODE" seçeneği ile üretilen kodu kopyalıyoruz.

    Eğer birden çok sayfa Notion sayfasını kullanmak isterseniz, "ADD A PRETTY LINK"  seçeneği ile yapabilirsiniz.

    [https://csb-vydqj.stephenou.now.sh](https://csb-vydqj.stephenou.now.sh)

18. Tekrar CloudFlare sayfasına geri dönelim. Burada karşımıza çıkan ekranda, sol taraftaki (Script yazan panel) tüm kodu silerek, az önce üretilen kodu buraya yapıştırıyoruz. "Save and Deploy" butonuna tıklıyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/7-cloudflare-code-ekle.png](https://cbsofyalioglucom.imfast.io/notion/7-cloudflare-code-ekle.png)

19. Şimdi sayfanın üst kısmında yer alan alan adımıza tıklayalım. Ardından, mavi kutucuklardan Workers butonuna tıklayarak İşçilerimizle alakalı sayfaya geçelim.
20. Buradaki "Add Route" butonuna tıklıyoruz. Burada kullanacağımız alan adını,  /* ekiyle giriyoruz. Örneğin: no-kod.com/* ya da alt alan adı kullanacaksak blog.no-kod.com/* . Son olarak daha önce aktif ettiğimiz workerımızı da seçtikten sonra kaydet tuşuna basarak işlermlerimizi bitiriyoruz.

    ![https://cbsofyalioglucom.imfast.io/notion/8-cloudflare-route-ekleme.png](https://cbsofyalioglucom.imfast.io/notion/8-cloudflare-route-ekleme.png)

21. Artık alan adımıza giderek Notion ile oluşturduğumuz sayfayı web sayfası olarak kullanabiliriz.

Artık sitenizi kullanmaya başlayabilirsiniz.

---

## Notion Nedir?

Notion sağladığı zengin bileşenler ve hayli özelleştirilebilir yapısı ile çok fazla amaç için kullanılabilen bir platform.

Not alma, bilgi platformu olarak kullanma, blog yazılarınızı kaydetme, yapılacaklar listesi oluşturma, kanban paneller, database oluşturma, proje planlama, ortak çalışma alanları yaratma, hazırladığınız sayfaların HTML veya Markdown olarak çıktısını alma gibi bir çok amaç için kullanılabilen, hem mobil, hem masaüstü (yalnızca macOS ve Windows) hem de bir web app olarak hizmet verebilen bir uygulama.

2016'da San Fransisco merkezli kurulan ve 2020 yılında 2 milyar dolar değerleme alan bir şirket aynı zamanda.Yanlış hatırlamıyorsam bir Evernote alternatifi olarak beta sürümünü görmüştüm ilk defa. Hiç bir zaman Evernote'a ısınamamış biri olarak ilgimi çekmişti ancak resmi bir Linux versiyonunun olmayışı biraz uzak kalmama sebep olmuştu.

Bugünse hala resmi bir API'a sahip olmayışları ve yol planlarında resmi API için öncelik barındırmamaları hala canımı sıksa da, bu benim gibi kullanıcılar için bir problem.

Çok spesifik ihtiyaçlarınız yoksa bir çok uygulamanızı bırakıp Notion'a geçmemeniz için hiç bir sepep yok.

Bu blog yazısında Stephen Ou'nun bir yan projesi olan FruitionSite sitesinde yayınladığı yöntemi uygulayarak Notion ile nasıl bir web sayfası yapılır onu göstermeye çalışacağım.

### Notion yapılan web sayfası örnekleri nelerdir?

Aşağıdaki görsellerde Notion ile yapılan web sayfası örneklerinden bir kaç tanesini bulabilirsiniz.

Ayrıca bu yazıda gösterilecek olan yöntemle yapılmış sitelerin listesine de buradan ulaşabilirsiniz:

![http://www.cbsofyalioglu.com/content/images/2020/07/showcase-fruition-1.jpg](http://www.cbsofyalioglu.com/content/images/2020/07/showcase-fruition-1.jpg)

## Notion İle Ücretsiz Web Sayfası Oluşturalım

Ben daha öncede GoDaddy'den aldığım no-kod.com alan adını bu örnek gösterim için kullanacağım. Herhangi bir alan adı sağlayıcısından almış olduğunuz alan adıyla da pek tabi bu işlemi gerçekleştirebilirsiniz. Tutarlı olmak ve örnek verirken kolaylık olması maksadıyla kendi kullanacağım alan adını tüm örneklerde kullanacağım.

### Notion ile Web Sayfası Yapmak için Gerekenler

Notion ile ücretsiz web sayfası oluşturmak için gereken iki önemli husus var. Bunlar:

- Bir Notion hesabımızın olması.
- Bir alan adına sahip olmamız (Örneğin: http://no-kod.com/. Herhangi bir alan adı sağlayıcısından ücretli olarak temin edebilirsiniz: GoDaddy gibi)Şu ana kadar zaten Notion hesabına sahip olduğunuzu ve de web sayfası olarak kullanmak istediğiniz alan adını almış olduğunuzu varsayıyorum. Bundan sonraki kısımda bir CloudFlare hesabı açıp, alan adınıza gelen trafiği Notion sayfanıza yönlendireceğiz.

### Adım Adım Notion ile Web Sayfamızı oluşturuyoruz

2. "Add A Site" butonuna tıklayarak kullanmak istediğiniz alan adınızı başında herhangi bir protokol ve alt alan adı olmadan girin. Örneğin: no-kod.com. Eğer www.no-kod.com ya da blog.no-kod.com gibi bir alt alan adını kullanacak da olsam gene de kök alan adını yani apex domain'im olan no-kod.com 'u girecektim.

3. Daha sonra "Free" seçeği ile ücretsiz planı seçiyoruz.

4. Bize alan adı sağlayıcımızla ilgili bilgileri gösterdikten sonra "Continue" ile devam ediyoruz.5. CloudFlare'in ad sunucularının olduğu ekrana geldik. Buradaki 2 adet ad sunucusunu (name servers) kendi alan adı sağlayıcımızın DNS ayarlarına gireceğiz. Böylece CloudFlare alan adımızla ilgili tek yetkili konumuna gelecek.

![https://static.wixstatic.com/media/b917b3_9eff9d0b80de4fae88ea372b4a1f951f~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_9eff9d0b80de4fae88ea372b4a1f951f~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

6.Alan adı sağlayıcımızda oturum açıp, kullanacağımız alan adının DNS ayarları sayfasına gidiyoruz. Benim örneğimi referans alırsak, GoDaddy'de oturum açıp, alan adlarım arasından no-kod.com' u bulup "Yönet" seçeneğine tıklıyorum.

![https://static.wixstatic.com/media/b917b3_b1d70ddbd42a4fd09f14d0b8840a11aa~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_b1d70ddbd42a4fd09f14d0b8840a11aa~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

7. Açılan sayfada alt kısımlarda Ad Sunucuları başlığında "Değiştir" butonuna tıklayarak, beşinci Adımda karşımıza çıkan CloudFlare Ad Sunucularını (NS) buraya girip kaydediyoruz. Kaydetmenin ardından artık CloudFlare alan adımız üzerinde tam yetkiye sahip oluyor.

![https://static.wixstatic.com/media/b917b3_56404a73def049f79b653c6055282849~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_56404a73def049f79b653c6055282849~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

8. Şimdi tekrardan CloudFlare'deki hesabımıza geri dönüyoruz. "Done, check nameservers" butonuna tıklıyoruz.9. Sonraki ekranda SSL/TLS modu olarak Flexible'ı seçiyoruz.

![https://static.wixstatic.com/media/b917b3_9eff9d0b80de4fae88ea372b4a1f951f~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_9eff9d0b80de4fae88ea372b4a1f951f~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

10. Always Use HTTPS seçeneğine tıklayarak aktif ediyor, Auto Minify seçeneklerinin hepsini seçiyor ve Brotli sıkıştırmasını da aktif ederek "Done" butonuna tıklıyoruz.

![https://static.wixstatic.com/media/b917b3_370b53cc448b4a2593462d82216373e0~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_370b53cc448b4a2593462d82216373e0~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

11. Ardından CloudFlare'in onay vermesini bekliyoruz. Eğer aşağıdaki ekran sizde çıkmadıysa, sayfayı yenileyebilirsiniz.

![https://static.wixstatic.com/media/b917b3_18c6600f39844643b90312d2130f090b~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_18c6600f39844643b90312d2130f090b~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

12. İşlemlerin başarılı olduğuna dair ekranı gördüyseniz, yukarıdaki mavi kutulardan "Workers" seçeneğini seçebilirsiniz. Yeni açılan sayfada, sağ taraftaki "Manage Workers" seçeneğine tıklayarak alan adına gelen trafiği, notion sayfamıza yönlendirecek worker'ımızı ayarlayacağız.

![https://static.wixstatic.com/media/b917b3_c814e22cd5d2402b98ea37880a2a668c~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_c814e22cd5d2402b98ea37880a2a668c~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

13. Sonraki ekranda çıkan herhangi bir alt alan adını seçebilirsiniz. Neyi seçitiğinizin çok da bir önemi yok. Global olarak benzersiz olması yeterli. Daha sonra "Set up" ve ardından "Confirm" seçenekleri ile işçimizi yaratıyoruz.

![https://static.wixstatic.com/media/b917b3_90dcfc84284b4e1d96afc55e99416b95~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_90dcfc84284b4e1d96afc55e99416b95~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

14. Sonraki ekranda tekrardan Free seçeneğini seçerek ücretsiz plan dahilinde kalıyoruz. Burada seçtiğimiz ücretsiz hesap için günlük bir limit uygulanıyor. Eğer siteniz fazla trafik çekecek ise daha sonra bir üst paketi seçebilirsiniz.

15. Eğer başka bir ekrandaysanız tekrardan mavi kutucuklar arasından Workers'a tıklayarak ilgili sayfaya geçiniz. Buradaki "Create a Worker" butonuna tıklayarak işçimizin görevlerini tanımlayacağız.

16. Bundan önce yapmamız gereken bir şey daha var. O da Notion'da oluşturduğumuz sayfaya giderek, bu sayfayı herkesin erişimine açık hale getirmek. Kullanacağımız sayfayı seçtikten sonra sağ üst köşedeki "Share" linkine tıklayarak ardından da "Share to the web" seçeneğini aktif hale getirip, "Copy Link" butonuna tıklıyor ve Notion sayfamızın global adresini kopyalıyoruz. Artık sayfamız herkesin erişimine açık hale gelmiş bulunmakta.

![https://static.wixstatic.com/media/b917b3_855ace92f9164f16a0e198c0cdead40c~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_855ace92f9164f16a0e198c0cdead40c~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

17. Aşağıdaki forma kutucukların birincisine kullanacağınız alan adını girin. Örneğin: no-kod.com. İkincisine ise bir önceki adımda kopyaladığımız, Notion sayfamızın web adresini giriyoruz. Ardından "COPY THE CODE" seçeneği ile üretilen kodu kopyalıyoruz. Eğer birden çok sayfa Notion sayfasını kullanmak isterseniz, "ADD A PRETTY LINK" seçeneği ile yapabilirsiniz.

(Not: Eğer form açılmazsa aynı işlemi bu linke tıklayarak yapabilirsiniz: https://csb-vydqj.stephenou.now.sh)

18. Tekrar CloudFlare sayfasına geri dönelim. Burada karşımıza çıkan ekranda, sol taraftaki (Script yazan panel) tüm kodu silerek, az önce üretilen kodu buraya yapıştırıyoruz. "Save and Deploy" butonuna tıklıyoruz.

![https://static.wixstatic.com/media/b917b3_ada78fd712ec49639583fb89acbe5984~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_ada78fd712ec49639583fb89acbe5984~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

19. Şimdi sayfanın üst kısmında yer alan alan adımıza tıklayalım. Ardından, mavi kutucuklardan "Workers" butonuna tıklayarak İşçilerimizle alakalı sayfaya geçelim.

20. Buradaki "Add Route" butonuna tıklıyoruz. Burada kullanacağımız alan adını, /* ekiyle giriyoruz. Örneğin: no-kod.com/* ya da alt alan adı kullanacaksak blog.no-kod.com/* . (Sondaki yıldız * işaretini unutmayın. Yıldız wildcard olup oraya gelebilecek her ihtimalin kabul edilmesini sağlar)Son olarak daha önce aktif ettiğimiz workerımızı da seçtikten sonra kaydet tuşuna basarak işlermlerimizi bitiriyoruz.

![https://static.wixstatic.com/media/b917b3_5c2581309bd440ce8a5e7bce3a5dd122~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png](https://static.wixstatic.com/media/b917b3_5c2581309bd440ce8a5e7bce3a5dd122~mv2.png/v1/fit/w_300,h_300,al_c,q_5/file.png)

Artık alan adımıza giderek Notion ile oluşturduğumuz sayfayı web sayfası olarak kullanabiliriz. Artık sitenizi kullanmaya başlayabilirsiniz..

## BONUS: Ücretli ve Ücretsiz Notion Şablonları